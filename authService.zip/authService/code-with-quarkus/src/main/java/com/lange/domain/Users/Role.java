package com.lange.domain.Users;

public enum Role {
    USER,
    ADMIN,
    SUPER_USER
}
