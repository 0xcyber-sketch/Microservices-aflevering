package com.lange.resources.login.dto;

public class CreatedDTO {

    private final String ID;

    public String getID() {
        return ID;
    }

    public CreatedDTO(String ID) {
        this.ID = ID;
    }
}
