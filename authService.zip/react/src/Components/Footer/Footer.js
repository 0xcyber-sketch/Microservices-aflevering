function Footer() {
    return (
        <>
        This is my footer
        </>
    )
}

export default Footer