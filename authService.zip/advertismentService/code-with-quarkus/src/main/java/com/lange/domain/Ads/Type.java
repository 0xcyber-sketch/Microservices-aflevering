package com.lange.domain.Ads;

public enum Type {
    SALE,
    PURCHASE,
    RENT

}
