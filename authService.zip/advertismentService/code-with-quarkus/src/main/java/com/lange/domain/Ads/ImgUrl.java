package com.lange.domain.Ads;

public class ImgUrl {

    private String Url;

    public ImgUrl(String URL) {
        Url = URL;
    }

    public String getUrl() {
        return Url;
    }
}
