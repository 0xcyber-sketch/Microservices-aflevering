package com.lange.domain.Ads;

public class Price {
    private final double value;

    public Price(double price){this.value = price;}

    public double getValue(){
        return value;
    }
}