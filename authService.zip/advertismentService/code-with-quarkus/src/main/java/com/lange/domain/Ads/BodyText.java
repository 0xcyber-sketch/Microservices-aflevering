package com.lange.domain.Ads;

public class BodyText {
    private final String value;
    public BodyText(String bodyText){this.value = bodyText;}
    public String getValue(){
        return value;
    }
}