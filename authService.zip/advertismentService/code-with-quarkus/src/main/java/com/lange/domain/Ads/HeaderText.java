package com.lange.domain.Ads;

public class HeaderText {
    private  String value;
    public HeaderText(String headerText){this.value = headerText;}

    public String getValue(){
        return value;
    }
}
