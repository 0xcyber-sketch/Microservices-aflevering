package com.lange.domain.Ads;

public class Mobile {
    public String number;

    public Mobile(String number) {
        this.number = number;
    }

    public String getNumber() {
        return number;
    }
}
