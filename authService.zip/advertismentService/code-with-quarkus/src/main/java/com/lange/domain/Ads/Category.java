package com.lange.domain.Ads;

public enum Category {
    CAR,
    FOOD,
    TOOLS,
    ANIMALS,
    TOYS,
    COLLECTABLES
}
